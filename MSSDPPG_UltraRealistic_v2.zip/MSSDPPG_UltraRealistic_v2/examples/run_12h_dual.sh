#!/usr/bin/env bash
set -e
python MSSDPPG_UltraRealistic_v2.py --duration 12h --mode both --assist on
