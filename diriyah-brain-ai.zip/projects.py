async def fetch_projects():
    return [
        {"id":1,"name":"Opera House – Foundation","location":"Diriyah","description":"Structural works","status":"On Track","progress":68,"deadline":"Dec 1, 2025","cloudService":"google","riskLevel":"medium"}
    ]
